import re
from rdkit import DataStructs, Chem
from rdkit.Chem import AllChem as AChem
import numpy as np
with open("mmc1.csv", "r") as f:
    content=f.readlines()

content=[re.split("," ,x) for x in content[2:]]
content=[[x[1], x[-3]] for x in content]



ACTIVATE=[AChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(x[0]), 4, nBits=2048) for x in content if x[-1]=="Active"]
UNA=[AChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(x[0]), 4, nBits=2048) for x in content if x[-1]!="Active"]
sim_dif=[]
sim_act=[]
sim_una=[]

for x in ACTIVATE:
    sim_dif.append(DataStructs.BulkTanimotoSimilarity(x, UNA, returnDistance=True))
for x in ACTIVATE:
    sim_act.append(DataStructs.BulkTanimotoSimilarity(x, ACTIVATE, returnDistance=True))
for x in UNA:
    sim_una.append(DataStructs.BulkTanimotoSimilarity(x, UNA, returnDistance=True))
print("Sim in dif is {} Sim in activate is {} Sim in unactivate is {}".format([np.mean(sim_dif), np.std(sim_dif)], [np.mean(sim_act), np.std(sim_act)], [np.mean(sim_una), np.std(sim_una)]))
#print(np.mean(sim_dif), np.mean(sim_act), np.mean(sim_una))
