config={
        "atom_path":"./atom.json",
        "bond_path":"./bond.json",
        "grammar_path":"./grammar.json",
        "raw_path":"./mmc1.csv",
        "save_path":"train.hdf5"
        }

