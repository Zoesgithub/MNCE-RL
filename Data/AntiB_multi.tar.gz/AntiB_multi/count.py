import json
with open("grammar.json", "r") as f:
    content=json.load(f)
print(len(content))
