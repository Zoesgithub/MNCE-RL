from rdkit import Chem
from config import config
import sys
sys.path.append("../../")
import json
import toolbox as tb
import numpy as np
from loguru import logger
import h5py 
import networkx as nx
from rdkit.Chem import Draw
from molvs import Standardizer
import re
logger.add("./mkdata.log")

def load_smile(path):
    with open(path, "r") as f:
        content=f.readlines()
    content=content[2:]
    content=[x.strip("\r\n").split(",") for x in content]
    content=[[float(x[0]), x[1]] for x in content]
    ret=[]
    logger.info("Dataset size {}".format(len(content)))
    size=0
    for x in content:
        mol=Chem.MolFromSmiles(x[1], sanitize=True)
        Standardizer().standardize(mol)
        Chem.SanitizeMol(mol)
        Chem.Kekulize(mol)
        ret.append([mol, x[0]])
        s=len([x for x in mol.GetAtoms()])
        if s>size:
            size=s
    logger.info("The maxsize is {}",format(size))
    return ret, size


def mol_to_matrix(mol, atoms, bonds, size):
    Chem.Kekulize(mol)
    graph=tb.mol2nodegraph(mol)
    ns=[x for x in graph.nodes]
    mol=np.zeros(size)
    adj=np.zeros([size, size], dtype=int)
    #tadj=nx.adjacency_matrix(graph, ns, weight="name")
    for i, x in enumerate(ns):
        for j, y in enumerate(ns):
            #print(i,x,y)
            #print(graph.adj[x][y])
            if y in graph.adj[x]:
                #print(graph.adj[x][y])
                adj[i][j]=bonds[graph.adj[x][y]["name"]]
    for i, x in enumerate(ns):
        sym=graph.nodes[x]["name"]
        sym=sym.split("-")[0]
        if not sym in atoms:
            print(sym)
            #return None, None
            atoms[sym]=len(atoms)
        mol[i]=atoms[sym]
    return mol, adj

def create_mask(diction):
    res={}
    names=sorted([int(x) for x in diction])
    for i,n in enumerate(names):
        assert i==n
        prod=diction[n]
        lhs, embedding, rhs, box, _=prod
        name=("=".join(lhs)).replace("<", "-").replace(">", "-")
        if not name in res:
            #print(name)
            res[name]=np.zeros(len(names)).tolist()
        res[name][i]+=1
        """if "none" in name:
            tname=[]
            i=0
            for x, y in zip(lhs, embedding):
                y=re.split("/",y)
                _, bond, _=re.split("\[|\]", y[1])
                if "none" in x:
                    tname.append(x.replace("none", bond))
                    name=("=".join(tname+lhs[i+1:])).replace("<", "-").replace(">", "-")
                    if not name in res:
                        print(name)
                        res[name]=np.zeros(len(names)).tolist()
                    res[name][i]=1
                else:
                    tname.append(x)
                i+=1"""

    #print([max(res[x]) for x in res])
    for x in res:
        #print(x, "\n")
        for i,y in enumerate(res[x]):
            if y>0:
                #print(diction[str(i)][0:3])
                pass
    return res

def load_json(path):
    with open(path, "r") as f:
        content=json.load(f)
    return content
def getatom_bond(diction):
    atoms={}
    bonds={}
    for x in diction:
        rhs=diction[x][2]
        for y in rhs:
            bond=re.split("\[|\]", y)
            atom=bond[0]
            if len(bond)>1:
                bond=bond[1]
                if not bond in bonds:
                    bonds[bond]=len(bonds)
            atom=re.split("<-|->", atom)
            atom=[x.split("-")[0] for x in atom]
            for z in atom:
                if not z in atoms and z!="X" and z!="J":
                    print("{}\t{}".format(z,y))
                    atoms[z]=len(atoms)

    bonds["none"]=len(bonds)
    bonds["None"]=len(bonds)
    atoms["START"]=len(atoms)
    atoms["X"]=len(atoms)
    atoms["J"]=len(atoms)
    return atoms, bonds

if __name__=="__main__":
    import os
    os.environ["HDF5_USE_FILE_LOCKING"] = "FALSE"
    rawpath=config["raw_path"]
    savepath=config["save_path"]
    #grammarpath=config["grammar_path"]


    files=[]

    mols, size=load_smile(rawpath)
    num=0
    Trueth=0
    grammar={}
    cmols=[]
    validv=0
    for i,Mol in enumerate(mols):
        print(i)
        tmpmol=tb.nodegraph2mol(tb.mol2nodegraph(Chem.Mol(Mol[0])))
        #if len(tmpmol.GetAtoms())<len(Mol[0].GetAtoms()):
        #    continue
        validv+=1
        start=0
        while start<len(Mol[0].GetAtoms()):
            try:
                tree, mol=tb.parsemol(Mol[0], grammar, start=start)
                files.append(tree)
                start+=1
            except:
                break
        cmols.append([mol, Mol[1]])
            
    with open("grammar.jsonori", "w") as f:
        f.write(json.dumps(grammar))
    grammar={grammar[x][0]:grammar[x][1] for x in grammar}
    with open("grammar.json", "w") as f:
        f.write(json.dumps(grammar))
    masks=create_mask(grammar)
    with open("mask.json", "w") as f:
        f.write(json.dumps(masks))
    atoms, bonds=getatom_bond(grammar)
    print(bonds, atoms)
    logger.info("Data size {} True size {}".format(len(cmols), len(files)))
    with open("mmc1.json", "w") as f:
        f.write(json.dumps(files))


    logger.info("{}".format(atoms))
    logger.info("{}".format(bonds))

    f=h5py.File(savepath, "w")
    mol=f.create_dataset("Mol", (len(cmols), size), dtype=int)
    adj=f.create_dataset("Adj", (len(cmols), size, size), dtype=int)
    score=f.create_dataset("Score", (len(cmols), ), dtype=float)
    index=0
    for i, x in enumerate(cmols):
        m, a=mol_to_matrix(x[0], atoms, bonds, size)
        if m is None:
            continue
        mol[index]=m
        adj[index]=a
        score[index]=x[1]
        index+=1
    logger.info("{}".format(atoms))
    logger.info("{}".format(index))
    with open("atom.json", "w") as f:
        f.write(json.dumps(atoms))
    with open("bond.json", "w") as f:
        f.write(json.dumps(bonds))
    f.close()
